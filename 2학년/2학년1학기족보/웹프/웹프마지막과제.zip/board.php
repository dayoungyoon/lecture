<?

 $mydb = mysql_connect("localhost","root",apmsetup,webdb);
 mysql_query("set names utf-8");
 $db_id = mysql_select_db('webdb',$mydb);

 $sql = "select * from board";
 $result = mysql_query($sql,$mydb);
 $total_record = mysql_num_rows($result);

 echo "<table border='2' cellspacing='2' cellpadding='2' bordercolor='#999999' style='border-collapse:collapse;''>";
 echo "<tr bgcolor='#B7F0B1'><td><center><b>No</b></center></td><td><center><b>����</b></center></td><td><center><b>����</b></center></td><td><b>�ۼ���</b></td>";
 while($row_array=mysql_fetch_array($result)){
	 echo "<tr>\n\t";
	 echo "<td width='50' bgcolor='#F2FFED'><center>$row_array[num]</center></td>";
	 echo "<td width='140' bgcolor='#F2FFED'>$row_array[title]</td>";
	 echo "<td width='300' bgcolor='#F2FFED'><center>$row_array[content]</center></td>";
	 echo "<td width='100' bgcolor='#F2FFED'>$row_array[writer]</td>";
	 echo "\n</tr>";
 }
 mysql_close($mydb);
 ?>