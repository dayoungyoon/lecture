/*#include <stdio.h>

class Database{//gildong
private:
	int a;
public:
	void operator<<(int i){ //Set->operator<<
		a=i;
	}
	
};

void main(){
	Database gildong;
	gildong<< 7; //=gildong.operator<<(7);  �������ߺ����� 
	
	getchar();
}*/